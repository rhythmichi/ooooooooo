enum BarType{
    SIMPLE,
    HEALTH,
    UNICOLOR_HEALTH
}