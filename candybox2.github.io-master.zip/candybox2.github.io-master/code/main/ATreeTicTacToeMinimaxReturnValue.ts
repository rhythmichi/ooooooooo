class ATreeTicTacToeMinimaxReturnValue{
    public bestPosition: Pos = null;
    public bestScore: number = null;
}