enum BigSharkFinType{
    RED,
    GREEN,
    PURPLE
}