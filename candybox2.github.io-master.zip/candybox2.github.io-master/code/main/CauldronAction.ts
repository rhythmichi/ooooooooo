enum CauldronAction{
    NOTHING,
    MIXING,
    BOILING
}