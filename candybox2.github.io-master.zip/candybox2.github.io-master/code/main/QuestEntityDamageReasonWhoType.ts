enum QuestEntityDamageReasonWhoType{
    NATURE,
    ENTITY
}