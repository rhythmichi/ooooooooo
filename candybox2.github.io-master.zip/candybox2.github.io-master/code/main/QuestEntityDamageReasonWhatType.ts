enum QuestEntityDamageReasonWhatType{
    WEAPON,
    SPELL
}