enum GalacticWarsStep{
    SPLASH_SCREEN,
    GAME,
    LOSE
}